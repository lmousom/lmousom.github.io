var amarta = document.getElementById("amarta");
var banasri = document.getElementById("banasri");
var braja = document.getElementById("braja");
var deb = document.getElementById("deb");
var laxmi = document.getElementById("laxmi");
var mani = document.getElementById("mani");
var pritam = document.getElementById("pritam");

amarta.innerHTML = 10;
//banasri.innerHTML = 00;
//braja.innerHTML = 00;
//deb.innerHTML = 00;
//laxmi.innerHTML = 00;
mani.innerHTML = 10;
//pritam.innerHTML = 00;
